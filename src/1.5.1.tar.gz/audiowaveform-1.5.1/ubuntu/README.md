# audiowaveform Packaging for Ubuntu Launchpad

Steps:

* Edit ./package.sh:
  * Edit audiowaveform version number
  * Add any new Ubuntu releases to publish to
* ./package.sh checkout
* ./package.sh sourcepackage
* ./package.sh debs
* ./package.sh publish

